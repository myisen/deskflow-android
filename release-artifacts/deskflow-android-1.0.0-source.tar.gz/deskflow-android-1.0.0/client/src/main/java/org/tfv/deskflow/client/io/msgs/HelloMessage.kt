/*
 * MIT License
 *
 * Copyright (c) 2025 Jonathan Glanz
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.tfv.deskflow.client.io.msgs

import org.tfv.deskflow.client.util.logging.KLoggingManager
import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * This message does not have a header
 */
class HelloMessage(
    var majorVersion: Int = 0,
    var minorVersion: Int = 0
) : Message(MessageType.HELLO) {

    override fun readData(inStream: DataInputStream, dataSize: Int) {
        majorVersion = inStream.readShort().toInt()
        minorVersion = inStream.readShort().toInt()
    }

    override fun writeData(outStream: DataOutputStream) {
        outStream.writeShort(majorVersion)
        outStream.writeShort(minorVersion)
    }



    companion object {

        private val log = KLoggingManager.logger(HelloMessage::class.java.simpleName)

        private const val HELLO_MESSAGE_SIZE = 11
    }
}
